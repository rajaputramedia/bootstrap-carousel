<?php
	include "koneksi.php";
	$query ="SELECT id, judul, deskripsi, gambar FROM tb_carousel ORDER BY id ASC";
    $result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Membuat Slider Bootstrap Carousel dengan PHP MySQL</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<!-- Bootstrap JavaScript -->
	<script type="text/javascript" src="assets/js/bootstrap.js"></script>
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
		<div class="carousel-indicators">
			<?php
			for($i=0; $i<$result->num_rows;$i++){
				echo '
				<button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="'.$i.'"';
				if($i==0){
				echo 'class="active" aria-current="true"';
				}
				echo'></button>';
			}
			?>
		</div>
		<div class="carousel-inner">
			<?php
			if($result->num_rows > 0){
				while ($row = $result->fetch_assoc()) {
				if($row['id'] == 1){
				echo'<div class="carousel-item active">';}else{echo'<div class="carousel-item">';}
				echo'<img src="image/'.$row['gambar'].'" class="d-block w-100" alt="'.$row['judul'].'">
					<div class="carousel-caption d-none d-md-block">
                    <h5>'.$row['judul'].'</h5>
                    <p>'.$row['deskripsi'].'</p>
					</div>  
				</div>';
			}}
			?>    
		</div>
		<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="visually-hidden">Previous</span>
		</button>
		<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
			<span class="visually-hidden">Next</span>
		</button>
	</div>
</body>
</html>